import os
import json
import hmac
import hashlib
import time
import threading
import requests
from flask import Flask, request, jsonify

# Import your newly engineered cryptographic token guard module filter
from token_guard import require_api_token

app = Flask(__name__)

# Security Token Parameters
PAYSTACK_SECRET_KEY = "sk_live_sample_zannie_key_99182"
PAYSTACK_WEBHOOK_SECRET = "whsec_zannie_signature_verification_token"

def process_order_fulfillment(event_data):
    """
    Handles background execution operations (such as sending confirmation emails,
    updating sales databases, and notifying fulfillment channels) without blocking
    the primary HTTP request-response thread loop.
    """
    try:
        # Extract unique data elements from verified transaction packet arrays
        data_payload = event_data.get("data", {})
        reference = data_payload.get("reference")
        amount = data_payload.get("amount", 0) / 100
        currency = data_payload.get("currency")
        customer_email = data_payload.get("customer", {}).get("email")

        print(f"\n[🧵 THREAD START] Processing Order Pipeline for Ref: {reference}")

        # Simulating heavy computational actions or external API hits (e.g., messaging engines)
        time.sleep(3)

        print(f"[💰 FULFILLMENT SUCCESS] Customer: {customer_email} | Amount: {amount} {currency}")
        print(f"[🧵 THREAD END] Background worker thread closed safely for Ref: {reference}\n")

    except Exception as e:
        print(f"[THREAD ERROR] Execution fault inside fulfillment worker: {e}")

@app.route("/api/v1/checkout/initialize", methods=["POST"])
@require_api_token  # Active Security Guard Intercept Layer Attached Here
def initialize_checkout():
    """Initializes transaction vectors and computes multi-currency exchange factors."""
    data = request.get_json() or {}
    base_price_usd = 85.00  # Example: Zannie Premium Footwear Item
    selected_currency = data.get("currency", "NGN").upper()

    # Simple fixed multi-currency scaling module mapping layer
    payable_amount = int(base_price_usd * 1500 * 100) if selected_currency == "NGN" else int(base_price_usd * 100)

    paystack_url = "https://api.paystack.co/transaction/initialize"
    headers = {
        "Authorization": f"Bearer {PAYSTACK_SECRET_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "email": data.get("email"),
        "amount": payable_amount,
        "currency": selected_currency
    }

    try:
        response = requests.post(paystack_url, json=payload, headers=headers, timeout=10)
        return jsonify(response.json()), response.status_code
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route("/api/v1/payments/webhook", methods=["POST"])
def paystack_webhook_listener():
    """Cryptographically verifies webhook authenticity and delegates jobs to threads."""
    payload_signature = request.headers.get("x-paystack-signature")
    if not payload_signature:
        print("[SECURITY ALERT] Webhook drop rejected: Missing cryptographic header token.")
        return jsonify({"status": "unauthorized"}), 401
        
    # Constant-time message authentication verification check pass
    computed_signature = hmac.new(
        key=PAYSTACK_WEBHOOK_SECRET.encode('utf-8'),
        msg=request.data,
        digestmod=hashlib.sha512
    ).hexdigest()
    
    if not hmac.compare_digest(computed_signature, payload_signature):
        print("[SECURITY ALERT] Malicious hash signature mismatch detected! Drop forced.")
        return jsonify({"status": "forbidden"}), 403

    event_data = json.loads(request.data)
    
    if event_data.get("event") == "charge.success":
        # Spawn an asynchronous background thread to handle fulfillment tasks cleanly
        worker_thread = threading.Thread(
            target=process_order_fulfillment,
            args=(event_data,)
        )
        worker_thread.daemon = True  # Daemon status allows clean shutdown with main engine loops
        worker_thread.start()
        
        print("[ROUTER] Webhook packet authenticated. Worker thread assigned successfully.")

    # Instantly return 200 OK to prevent connection timeout chains on the gateway
    return jsonify({"status": "accepted", "message": "Fulfillment processing initiated"}), 200

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001, debug=False)

