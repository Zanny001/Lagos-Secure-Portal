	mport json
import os
import traceback
import datetime
from flask import Flask, render_template, request
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import requests

app = Flask(__name__)
application = app

# ==========================================================
# CONFIGURATION & MEMORY CACHING CONSTANTS
# ==========================================================
SHEET_ID = "1Oy2q6YIVDe4kMMagomRm252Mf3INZgES87MFoUp72yA"
_gspread_client = None
DISCORD_WEBHOOK_URL = os.environ.get("DISCORD_WEBHOOK_URL", "")

# In-Memory Cache variables to limit redundant Google API round-trips
CACHE_TTL_SECONDS = 300  # 5-minute lifespan
_cache_data = None
_cache_timestamp = None

def get_google_sheets_client():
    global _gspread_client
    if _gspread_client is not None:
        return _gspread_client
    try:
        raw_data = os.environ.get("GOOGLE_CREDENTIALS_JSON")
        if not raw_data or raw_data == ".":
            return None
        creds = json.loads(raw_data)
        if "private_key" in creds and "\\n" in creds["private_key"]:
            creds["private_key"] = creds["private_key"].replace("\\n", "\n")
        scopes = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
        g_creds = ServiceAccountCredentials.from_json_keyfile_dict(creds, scopes)
        _gspread_client = gspread.authorize(g_creds)
        return _gspread_client
    except Exception as e:
        traceback.print_exc()
        return None

def get_worksheet():
    client = get_google_sheets_client()
    if not client:
        return None
    try:
        return client.open_by_key(SHEET_ID).get_worksheet(0)
    except Exception as e:
        return None

def fetch_cached_records(ws, force_refresh=False):
    """Handles performance optimization and rate limit protection."""
    global _cache_data, _cache_timestamp
    now = datetime.datetime.now()
    
    if (not force_refresh and 
            _cache_data is not None and 
            _cache_timestamp is not None and 
            (now - _cache_timestamp).total_seconds() < CACHE_TTL_SECONDS):
        return _cache_data

    try:
        _cache_data = ws.get_all_records()
        _cache_timestamp = now
        return _cache_data
    except Exception as e:
        print(f"[CACHE FALLBACK] {str(e)}")
        return _cache_data if _cache_data is not None else []

def send_discord_notification(company_name, rc_number, status, message_source):
    if not DISCORD_WEBHOOK_URL:
        return
    timestamp_str = datetime.datetime.utcnow().isoformat()
    payload = {
        "embeds": [
            {
                "title": "🚨 Secure Portal Registry Activity Log",
                "color": 3094400 if status == "VERIFIED" else 15151360,
                "fields": [
                    {"name": "🏢 Business Entity Name", "value": str(company_name), "inline": True},
                    {"name": "🔢 RC Registration Number", "value": str(rc_number), "inline": True},
                    {"name": "✅ Verification Status", "value": f"`{status}`", "inline": True},
                    {"name": "⚡ Activity Route Source", "value": str(message_source), "inline": False}
                ],
                "timestamp": timestamp_str
            }
        ]
    }
    try:
        requests.post(DISCORD_WEBHOOK_URL, json=payload, headers={"Content-Type": "application/json"})
    except Exception as e:
        print(e)

# ==========================================================
# CENTRAL PORTAL APP ROUTE HANDLER (STRICT MATCH TUNING)
# ==========================================================
@app.route("/", methods=["GET", "POST"])
def dashboard():
    ws = get_worksheet()
    if not ws:
        return "<h1>Database Interface Offline</h1>", 500

    admin_mode = request.form.get("admin_mode") == "true"
    raw_company = request.form.get("company_name", "").strip()
    raw_rc = request.form.get("rc_number", "").strip()
    
    # Normalize values for highly resilient lookup calculations
    input_company = raw_company.lower()
    input_rc = raw_rc.lower()
    
    result = None
    not_found = False
    newly_added = False

    records = fetch_cached_records(ws)

    if request.method == "POST" and (raw_company or raw_rc):
        # 1. STRICT SCANNING LOOP: BOTH keys must align perfectly (AND condition logic)
        for row in records:
            # Safely handle potential field mismatches or key variation types in Google Sheets
            db_company = str(row.get("Company Name", "")).strip().lower()
            db_rc = str(row.get("RC Number", "")).strip().lower()
            
            # CRITICAL SECURITY FIX: Eliminate ambiguous loose false-positive matching
            if db_company == input_company and db_rc == input_rc:
                result = {
                    "Company Name": row.get("Company Name"), # Preserves proper lookbook capitalization
                    "RC Number": row.get("RC Number"),
                    "Verification Status": "VERIFIED",
                    "Last Checked Timestamp": row.get("Last Checked Timestamp", datetime.datetime.now().strftime("%Y-%m-%d %H:%M"))
                }
                break
        
        # 2. SEPARATION LOGIC ROUTE FOR MISSING MATCHES
        if not result:
            current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
            final_company = raw_company if raw_company else "N/A"
            final_rc = raw_rc if raw_rc else "N/A"
            
            if admin_mode:
                # If admin panel clearance flag is checked, insert record as a newly verified block
                new_row = [final_company, final_rc, "VERIFIED", current_time]
                try:
                    ws.append_row(new_row)
                    send_discord_notification(final_company, final_rc, "VERIFIED", "Admin Control Portal Override")
                    
                    result = {
                        "Company Name": final_company,
                        "RC Number": final_rc,
                        "Verification Status": "VERIFIED",
                        "Last Checked Timestamp": current_time
                    }
                    newly_added = True
                    # Force Cache Flush so the UI list registers the item instantly below
                    records = fetch_cached_records(ws, force_refresh=True)
                except Exception as e:
                    print(f"[SPREADSHEET WRITE FAULT] {e}")
            else:
                # Non-admin strict verification mode returns an uncompromised Risk Warning State
                not_found = True
                result = {
                    "Company Name": final_company,
                    "RC Number": final_rc,
                    "Verification Status": "NOT FOUND",
                    "Last Checked Timestamp": current_time
                }

    return render_template(
        "index.html", 
        result=result, 
        not_found=not_found, 
        newly_added=newly_added, 
        records=records
    )

if __name__ == "__main__":
    app.run(debug=True)

