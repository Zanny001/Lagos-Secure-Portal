import time
from pipeline import init_database, save_leads_batch, export_leads_to_csv # <-- Added export function

def simulate_web_harvester():
    print("[START] Launching Background Lagos Harvester Service Engine...")
    init_database()
    
    target_directories = ["b2b_market_page1", "b2b_market_page2", "b2b_market_page3"]
    
    for current_page in target_directories:
        print(f"\n[NETWORK] Fetching unparsed data matrices from: {current_page}...")
        time.sleep(1.0)
        
        raw_scraped_buffer = [
            ("Zannie Fashion Hub", "0803 123 4567", "Ikeja, Lagos", "Fashion & Apparel"),
            ("Lagos Tech Ventures", "+234-815-999-8888", "Yaba, Lagos", "Technology Services"),
            ("Invalid Scraping Artifact", "9912", "Unknown Hub", "Corrupt Garbage Data"),
            ("Alaba Logistics Group", "09011223344", "Alaba, Ojo", "Logistics & Freight"),
            ("Duplicate Listing Inc", "08031234567", "Ikeja, Lagos", "Fashion & Apparel")
        ]
        
        print(f"[PROCESSOR] Extracted {len(raw_scraped_buffer)} items. Passing to database filters...")
        new_records_saved = save_leads_batch(raw_scraped_buffer)
        print(f"[SUCCESS] Safely committed {new_records_saved} unique B2B leads from {current_page}.")

    # <-- Trigger the Reporting Layer output routine once extraction cycles finish completely
    print("\n[REPORTING] Data collection sweep concluded. Generating deliverable matrix...")
    export_leads_to_csv()

if __name__ == "__main__":
    simulate_web_harvester()

