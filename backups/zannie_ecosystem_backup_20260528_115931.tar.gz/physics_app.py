import os
import requests
from datetime import datetime
from flask import Flask, render_template_string, request, jsonify

app = Flask(__name__)

# Discord Webhook configuration for parental progress updates
DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/mock_crypto_channel_token"

# Master Answer Key with domain tracking for targeted analytics
PHYSICS_ANSWER_KEY = {
    1: {"question": "What are the fundamental dimensions of Force?", "topic": "Dimensions", "correct": "A", "options": {"A": "MLT⁻²", "B": "ML²T⁻²", "C": "MLT⁻¹", "D": "M²LT⁻²"}},
    2: {"question": "Which of the following is a scalar quantity?", "topic": "Mechanics", "correct": "C", "options": {"A": "Weight", "B": "Velocity", "C": "Mass", "D": "Acceleration"}},
    3: {"question": "A body moving in a circular path at a constant speed has a:", "topic": "Circular Motion", "correct": "B", "options": {"A": "Constant velocity", "B": "Centripetal acceleration", "C": "Zero acceleration", "D": "Constant momentum"}},
    4: {"question": "Calculate the work done when a force of 10N moves an object through 5m in its own direction.", "topic": "Mechanics", "correct": "A", "options": {"A": "50 J", "B": "2 J", "C": "0.5 J", "D": "15 J"}},
    5: {"question": "What is the dimensional formula for Work Done?", "topic": "Dimensions", "correct": "D", "options": {"A": "MLT⁻²", "B": "ML³T⁻²", "C": "MLT⁻¹", "D": "ML²T⁻²"}},
    6: {"question": "The rate of change of momentum is directly proportional to the applied force. This is Newton's:", "topic": "Mechanics", "correct": "B", "options": {"A": "1st Law", "B": "2nd Law", "C": "3rd Law", "D": "Law of Gravitation"}},
    7: {"question": "The force that keeps a satellite in orbit around the earth is called:", "topic": "Circular Motion", "correct": "C", "options": {"A": "Frictional force", "B": "Electrostatic force", "C": "Gravitational force", "D": "Centrifugal force"}},
    8: {"question": "An object drops from a height. Its kinetic energy is maximum at:", "topic": "Mechanics", "correct": "A", "options": {"A": "Just before hitting the ground", "B": "The halfway point", "C": "The starting point", "D": "Varies unpredictably"}},
    9: {"question": "Which of the following quantities is dimensionless?", "topic": "Dimensions", "correct": "B", "options": {"A": "Acceleration", "B": "Refractive Index", "C": "Density", "D": "Speed"}},
    10: {"question": "The angular velocity of a particle moving in a circle of radius 2m with a linear speed of 10m/s is:", "topic": "Circular Motion", "correct": "D", "options": {"A": "20 rad/s", "B": "0.2 rad/s", "C": "2 rad/s", "D": "5 rad/s"}}
}

def dispatch_parent_report_webhook(student_name, score, percentage, remarks, topic_breakdown):
    """Formats and transmits a comprehensive analytical student metrics card to Discord."""
    breakdown_str = ""
    for topic, stats in topic_breakdown.items():
        pct = (stats["correct"] / stats["total"]) * 100
        breakdown_str += f"📚 **{topic}**: `{stats['correct']}/{stats['total']}` ({pct:.0f}% Mastery)\n"

    # Set embed color: Emerald Green for pass/excellence (>=70%), Warning Amber/Red otherwise
    embed_color = 3066993 if percentage >= 70 else 15105570

    payload = {
        "embeds": [{
            "title": "📝 ACADEMIC PERFORMANCE ASSESSMENT MATRIX",
            "color": embed_color,
            "description": f"Official evaluation scorecard compiled on {datetime.now().strftime('%Y-%m-%d %H:%M')}.",
            "fields": [
                {"name": "Student Name", "value": f"👤 **{student_name}**", "inline": True},
                {"name": "Overall Grade", "value": f"🎯 **{score} / 10** (`{percentage}%`)", "inline": True},
                {"name": "Performance Evaluation Remarks", "value": f"📋 *{remarks}*", "inline": False},
                {"name": "Structural Domain Performance Breakdown", "value": breakdown_str, "inline": False}
            ],
            "footer": {"text": "Zannie Academic Portal Infrastructure Engine"},
            "timestamp": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        }]
    }

    try:
        # 5-second timeout safeguard for mobile network instability
        response = requests.post(DISCORD_WEBHOOK_URL, json=payload, timeout=5)
        return response.status_code == 204
    except Exception as e:
        print(f"[CRITICAL] Webhook routing failure: {e}")
        return False

# Integrated mobile-first HTML layout template utilizing a modern dashboard UI
DASHBOARD_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Physics Assessment Portal</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background-color: #f7fafc; color: #2d3748; margin: 0; padding: 20px; }
        .container { max-width: 650px; margin: 0 auto; background: #ffffff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05); }
        h1 { color: #1a365d; font-size: 24px; border-bottom: 3px solid #319795; padding-bottom: 10px; margin-top: 0; }
        .form-group { margin-bottom: 20px; }
        label { font-weight: bold; display: block; margin-bottom: 8px; color: #2c5282; }
        input[type="text"] { width: 100%; padding: 10px; border: 1px solid #cbd5e0; border-radius: 4px; box-sizing: border-box; font-size: 16px; }
        .question-card { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 15px; margin-bottom: 15px; }
        .question-text { font-weight: 600; margin-bottom: 10px; color: #2d3748; }
        .option-label { display: block; padding: 8px; margin: 4px 0; background: #fff; border: 1px solid #edf2f7; border-radius: 4px; cursor: pointer; transition: background 0.2s; }
        .option-label:hover { background: #edf2f7; }
        .option-label input { margin-right: 10px; }
        .submit-btn { width: 100%; background: #319795; color: white; border: none; padding: 12px; border-radius: 4px; font-size: 18px; font-weight: bold; cursor: pointer; margin-top: 15px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .submit-btn:hover { background: #2c7a7b; }
        .result-box { margin-top: 25px; background: #ebf8ff; border-left: 4px solid #3182ce; padding: 20px; border-radius: 0 6px 6px 0; }
        .result-title { color: #2b6cb0; font-size: 20px; font-weight: bold; margin-top: 0; }
        .topic-badge { display: inline-block; background: #e2e8f0; color: #4a5568; font-size: 11px; padding: 2px 6px; border-radius: 4px; font-weight: bold; margin-bottom: 5px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Physics Curriculum Evaluation Portal</h1>
        
        {% if report %}
        <div class="result-box">
            <div class="result-title">⚡ Assessment Scorecard Submitted</div>
            <p><b>Student:</b> {{ report.name }}</p>
            <p><b>Score:</b> {{ report.score }} / 10 (<b>{{ report.pct }}%</b>)</p>
            <p><b>Evaluation Summary:</b> <i>{{ report.remarks }}</i></p>
            <hr style="border: 0; border-top: 1px solid #cbd5e0; margin: 15px 0;">
            <p><b>Domain Breakdown:</b></p>
            <ul>
                {% for topic, stats in report.breakdown.items() %}
                <li><b>{{ topic }}:</b> {{ stats.correct }} / {{ stats.total }}</li>
                {% endfor %}
            </ul>
            <p style="font-size: 12px; color: #718096; margin-bottom: 0;">🛰️ <i>Performance data has been synchronized and pushed to parent communication webhooks.</i></p>
            <a href="/" style="display: inline-block; margin-top: 15px; color: #319795; font-weight: bold; text-decoration: none;">← Run Another Assessment</a>
        </div>
        {% else %}
        
        <form method="POST">
            <div class="form-group">
                <label for="student_name">Student Legal Full Name:</label>
                <input type="text" id="student_name" name="student_name" placeholder="e.g., KEHINDE" required>
            </div>
            
            {% for q_id, info in questions.items() %}
            <div class="question-card">
                <div class="topic-badge">{{ info.topic }}</div>
                <div class="question-text">Q{{ q_id }}: {{ info.question }}</div>
                {% for opt_letter, opt_text in info.options.items() %}
                <label class="option-label">
                    <input type="radio" name="q_{{ q_id }}" value="{{ opt_letter }}" required>
                    <b>{{ opt_letter }})</b> {{ opt_text }}
                </label>
                {% endfor %}
            </div>
            {% endfor %}
            
            <button type="submit" class="submit-btn">Compile Results & Broadcast Report</button>
        </form>
        {% endif %}
    </div>
</body>
</html>
"""

@app.route("/", methods=["GET", "POST"])
def assess_grade():
    if request.method == "POST":
        student_name = request.form.get("student_name", "").strip().upper()
        if not student_name:
            return "Student name is required.", 400
            
        score = 0
        topic_performance = {}

        # Parse submission inputs across the master answer key map
        for q_id, info in PHYSICS_ANSWER_KEY.items():
            topic = info["topic"]
            if topic not in topic_performance:
                topic_performance[topic] = {"correct": 0, "total": 0}
            topic_performance[topic]["total"] += 1

            # Get user choice, default to empty string if missing
            chosen_option = request.form.get(f"q_{q_id}", "").strip().upper()
            if chosen_option == info["correct"]:
                score += 1
                topic_performance[topic]["correct"] += 1

        percentage = int((score / len(PHYSICS_ANSWER_KEY)) * 100)
        
        # Performance range determination
        if percentage >= 85:
            remarks = "Excellent mastery. Demonstrating outstanding retention and application of concepts."
        elif percentage >= 70:
            remarks = "Strong capability. Good conceptual alignment with physics principles."
        elif percentage >= 50:
            remarks = "Satisfactory progress. Targeted review sessions recommended for weak domains."
        else:
            remarks = "Urgent attention recommended. Comprehensive structural review requested."

        # Execute parent update broadcast sub-routine
        dispatch_parent_report_webhook(student_name, score, percentage, remarks, topic_performance)
        
        report = {
            "name": student_name,
            "score": score,
            "pct": percentage,
            "remarks": remarks,
            "breakdown": topic_performance
        }
        return render_template_string(DASHBOARD_TEMPLATE, report=report)

    return render_template_string(DASHBOARD_TEMPLATE, questions=PHYSICS_ANSWER_KEY, report=None)

if __name__ == "__main__":
    # Binding cleanly to port 5002 inside your mobile architecture layer
    app.run(host="0.0.0.0", port=5002, debug=True)

